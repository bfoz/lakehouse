Customer:
 Brandon Fosdick
 1553 Vista Club Circle 
 Apt 202
 Santa Clara CA, 95054
Mobile: 408-393-2734

Files:

pic_can_switch_v2.cmp   Component Side, Gerber 274X (top)
pic_can_switch_v2.sol   Solder Side, Gerber 274X (bottom)
pic_can_switch_v2.plc   Silkscreen, Gerber 274X (top)
pic_can_switch_v2.pls   Silkscreen, Gerber 274X (bottom)
pic_can_switch_v2.stc   Solder mask, Gerber 274X (top/component)
pic_can_switch_v2.sts   Solder mask, Gerber 274X (bottom/solder)
pic_can_switch_v2.drd   Excellon drill file
pic_can_switch_v2.dri   Drill info file
pic_can_switch_v2.brd   Eagle CAD board file

Note:
	pic_can_switch_v2.plc (top silkscreen layer) contains board outline
	pic_can_switch_v2.pls is bottom silkscreen layer (and board outline again)
