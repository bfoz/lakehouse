Customer:
 Brandon Fosdick
 1543 Vista Club Circle #201
 Santa Clara CA, 95054
Mobile: 408-393-2734

Files:

bridge.cmp   Component Side, Gerber 274X (top)
bridge.sol   Solder Side, Gerber 274X (bottom)
bridge.plc   Silkscreen, Gerber 274X (top)
bridge.stc   Solder mask, Gerber 274X (top/component)
bridge.sts   Solder mask, Gerber 274X (bottom/solder)
bridge.drd   Excellon drill file
bridge.dri   Drill info file
bridge.brd   Eagle CAD board file

Note:
	bridge.plc (silkscreen layer) contains board outline
